package com.ezzattest.pricepredictor.controller.rest;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ezzattest.pricepredictor.entity.Device;
import com.ezzattest.pricepredictor.helper.ResponseData;
import com.ezzattest.pricepredictor.service.DeviceService;
import com.google.gson.Gson;
import com.google.gson.JsonObject;

import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.http.MediaType;
import org.springframework.http.HttpHeaders;
import reactor.core.publisher.Mono;


@RestController
@RequestMapping("/api")
public class DeviceRestController {
	
	@Autowired
	DeviceService deviceService;
	
	@GetMapping("/devices")
	public List<Device> getDeviceList(){
	List<Device> devicesList = deviceService.getAllDevices();
		System.out.println(devicesList.toString());
		return devicesList;
	}

	@GetMapping("/devices/{id}")
	public Optional<Device> getDevice( @PathVariable("id") long id){
		Optional<Device> dev = deviceService.getDeviceId(id);
		System.out.println(dev.toString());
		return dev;
	}
	
	@PostMapping("/devices")
	public ResponseData saveDevice(@RequestBody Device device) {

		ResponseData responseData = new ResponseData();
		System.err.println(device);
		try {
			
			Device dev = deviceService.save(device);
			
			responseData.setData(dev);
			responseData.setStatusCode(201);
			responseData.setMessage("Device Save Successfully");
			responseData.setStatus("OK");
			
			return responseData;

		} catch (Exception e) {
			e.printStackTrace();
			responseData.setData(null);
			responseData.setStatusCode(500);
			responseData.setMessage(e.getMessage());
			responseData.setStatus("problem");
			
			return responseData;
		}

		
	}
	
	
	public String sendPostRequest(Object dev) {
        WebClient webClient = WebClient.create();

        // Request body
        Object requestBody = dev;

        // Headers
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);

        // POST request
        String url = "http://127.0.0.1:8000/predict/";
        try {
            Mono<String> responseBodyMono = webClient.post()
                    .uri(url)
                    .headers(httpHeaders -> httpHeaders.addAll(headers))
                    .bodyValue(requestBody)
                    .retrieve()
                    .bodyToMono(String.class);

            // Get the response body
            String responseBody = responseBodyMono.block();
            System.out.println("Response from server: " + responseBody);
            return responseBody; 
        } catch (Exception e) {
            e.printStackTrace();
            System.err.println("Error occurred during POST request: " + e.getMessage());
            return e.getMessage(); 
        }
    }


	@PostMapping("/predict/{id}")
	public ResponseData updateDevicePrice(@PathVariable("id") long id) {
		System.out.println("Update Rest....");
		ResponseData responseData = new ResponseData();
		try {
			
			Optional<Device> dev = deviceService.getDeviceId(id);

			String response = sendPostRequest(dev);
			
			JsonObject jsonObject = new Gson().fromJson(response, JsonObject.class);

        	int priceRange = jsonObject.get("price_range").getAsInt();



			Device updatedDevice =  deviceService.updateDevicePriceRange(priceRange, id);
			
			responseData.setStatusCode(200);
			responseData.setMessage("Device Updated Successfully");
			responseData.setData(updatedDevice);
			return responseData;
			
			
		} catch (Exception e) {
			responseData.setStatusCode(500);
			responseData.setMessage(e.getMessage());
			responseData.setData(null);
			return responseData;
		}
		
	}

	@DeleteMapping("/devices/{id}")
	public ResponseData deleteDevice(@PathVariable long id) {
		
		ResponseData responseData = new ResponseData();
		try {
			
			deviceService.deleteDevice(id);
			
			responseData.setStatusCode(204);
			responseData.setStatus("deleted");
			responseData.setMessage("Device Deleted Successfully.");
			
			
			return responseData;
			
		} catch (Exception e) {
			responseData.setData(null);
			responseData.setStatus("error");
			responseData.setStatusCode(500);
			responseData.setMessage(e.getMessage());
			
			
			return responseData;
			
		}
	}

}
