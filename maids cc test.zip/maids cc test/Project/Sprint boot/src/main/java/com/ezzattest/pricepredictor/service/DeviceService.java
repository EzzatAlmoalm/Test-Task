package com.ezzattest.pricepredictor.service;

import java.util.List;
import java.util.Optional;

import com.ezzattest.pricepredictor.entity.Device;

public interface DeviceService {

	List<Device> getAllDevices();

	Device save(Device employee);

	Optional<Device> getDeviceId(long id);

	Device updateDevicePriceRange(Integer price, long id);

	void deleteDevice(long id);

	

}
