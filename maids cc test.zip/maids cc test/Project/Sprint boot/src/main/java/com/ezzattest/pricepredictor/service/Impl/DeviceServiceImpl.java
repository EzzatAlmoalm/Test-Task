package com.ezzattest.pricepredictor.service.Impl;

import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ezzattest.pricepredictor.entity.Device;
import com.ezzattest.pricepredictor.repository.DeviceRepository;
import com.ezzattest.pricepredictor.service.DeviceService;
@Service
public class DeviceServiceImpl implements DeviceService{
	
	@Autowired
	DeviceRepository deviceRepository;
	
	@Override
	public List<Device> getAllDevices() {
		return deviceRepository.findAll();
	}

	@Override
	public Device save(Device employee) {
		return deviceRepository.save(employee);
	}

	@Override
	public Optional<Device> getDeviceId(long id) {
		return deviceRepository.findById(id);
	}

	@Override
	public Device updateDevicePriceRange(Integer price, long id) {
		Device newDevice = new Device();
		
		Optional<Device> oldDevice = deviceRepository.findById(id);
		if(oldDevice.isPresent()) {
			oldDevice.get().setPrice_range(price);

			newDevice = deviceRepository.save(oldDevice.get());

		}
		
		return newDevice;
	}

	@Override
	public void deleteDevice(long id) {
		deviceRepository.deleteById(id);
	}

}
