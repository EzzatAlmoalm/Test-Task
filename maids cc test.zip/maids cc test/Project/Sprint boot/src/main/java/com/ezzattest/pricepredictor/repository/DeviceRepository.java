package com.ezzattest.pricepredictor.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.ezzattest.pricepredictor.entity.Device;
@Repository
public interface DeviceRepository extends JpaRepository<Device, Long> {

}
