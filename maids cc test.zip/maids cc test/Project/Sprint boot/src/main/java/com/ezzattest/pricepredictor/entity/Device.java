package com.ezzattest.pricepredictor.entity;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonFormat;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "devices")

@NoArgsConstructor
@AllArgsConstructor
@Data
public class Device {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	Long id;

	Integer battery_power;

	Integer blue;
	
	Float clock_speed;

	Integer dual_sim;

	Float fc;

	Integer four_g;

	Float int_memory;

	Float m_dep;

	Float mobile_wt;

	Float n_cores;

	Float pc;

	Float px_height;

	Float px_width;

	Float ram;

	Float sc_h;

	Float sc_w;

	Float talk_time;

	Integer three_g;

	Integer touch_screen;

	Integer wifi;

	Integer price_range;

	// @Column(name = "name")
	// String name;
	
	// String email;
	
	// String contact;
	
	// String address;
	
	// String department;
	
	@Column(name = "created_at", nullable = true, updatable = false, columnDefinition = "TIMESTAMP DEFAULT CURRENT_TIMESTAMP")
    @Temporal(TemporalType.TIMESTAMP)
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
	
    private Date CreatedAt;
	

}
