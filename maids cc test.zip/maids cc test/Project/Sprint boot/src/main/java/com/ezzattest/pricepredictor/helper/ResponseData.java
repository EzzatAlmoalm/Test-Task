package com.ezzattest.pricepredictor.helper;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class ResponseData {
	
	private String status;
	private long statusCode;
	private String message;
	private Object data;
	
	

}
