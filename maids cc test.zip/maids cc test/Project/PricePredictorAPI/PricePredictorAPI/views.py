import pandas as pd
import numpy as np
from joblib import load
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
from django.utils.decorators import method_decorator
from django.views import View
import json
from django.views.decorators.csrf import csrf_exempt
from sklearn.preprocessing import MinMaxScaler

def scale_data(train_data):
 
    # Initialize MinMaxScaler
    scaler = MinMaxScaler()
    
    # Fit and transform the input device ent  data
    input_scaled= scaler.fit_transform(train_data)
      
    return input_scaled
@csrf_exempt
def predictView(request):
    if request.method == 'POST':
        data = json.loads(request.body)
        
# Create a Mobile object from the dictionary
        
        try:
            
            input_ent = []
                
                
            input_ent.append(data['battery_power'])
            input_ent.append(data['blue'])
            input_ent.append(data['clock_speed'])
            input_ent.append(data['dual_sim'])
            input_ent.append(data['fc'])
            input_ent.append(data['four_g'])
            input_ent.append(data['int_memory'])
            input_ent.append(data['m_dep'])
            input_ent.append(data['mobile_wt'])
            input_ent.append(data['n_cores'])
            input_ent.append(data['pc'])
            input_ent.append(data['px_height'])
            input_ent.append(data['px_width'])
            input_ent.append(data['ram'])
            input_ent.append(data['sc_h'])
            input_ent.append(data['sc_w'])
            input_ent.append(data['talk_time'])
            input_ent.append(data['three_g'])
            input_ent.append(data['touch_screen'])
            input_ent.append(data['wifi'])

            # print(input_ent)
            # breakpoint()
            # Load the trained model
            model = load("trained_model_lr.pkl")
           
            
            X_numpy =np.array(input_ent).reshape(1, -1)
            X_scaled = scale_data(X_numpy)
            price_range = model.predict(X_scaled)[0]
            price_range_int = int(price_range)

            return JsonResponse({'price_range' :price_range_int}, status=200)
            
        except FileNotFoundError:
            
            return JsonResponse({'error': 'Model not found'}, status=404)
        except Exception as e:
            
            return JsonResponse({'error': str(e)}, status=500)
    else:
        
        
        return JsonResponse({"error": "Method not allowed. Only POST requests are accepted."}, status=405)